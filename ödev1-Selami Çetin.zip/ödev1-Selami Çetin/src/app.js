import getData from "./lib/service.js";

const userId = 1;

getData(userId).then((result) => {
  console.log("Kullanıcı ve Post Verisi:");
  console.log(result);
});
